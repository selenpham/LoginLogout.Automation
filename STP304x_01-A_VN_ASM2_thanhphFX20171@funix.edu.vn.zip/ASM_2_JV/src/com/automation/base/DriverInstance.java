package com.automation.base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.automation.utils.Utility;

public class DriverInstance {

	public WebDriver driver;
//Khởi tạo	trình duyệt,chạy URL cần kiểm
		@BeforeMethod
	public void initiateriverInstance() throws IOException 
	{
		if(Utility.fetchPropertyValue("BrowserName").toString().equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			driver = new ChromeDriver();
		}
		
		else if (Utility.fetchPropertyValue("BrowserName").toString().equalsIgnoreCase("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./Driver/geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else if (Utility.fetchPropertyValue("BrowserName").toString().equalsIgnoreCase("ie"))
		{
			System.setProperty("webdriver.ie.driver", "./Driver/internetexplorerdriver.exe");
			driver = new InternetExplorerDriver();
		}
		else 
		{
			System.setProperty("webdriver.chrome.driver", "./Driver/chromedriver.exe");
			driver = new ChromeDriver();
		}
//Phóng to cửa sổ trình duyệt, chạy URL
    	driver.manage().window().maximize();	  
		driver.get(Utility.fetchPropertyValue("Application_URL").toString());
	    driver.manage().timeouts().pageLoadTimeout(15, TimeUnit.SECONDS);

		}
//Thoát URL
		
		@AfterMethod
		public void closeDriverInstance() 
		{
			driver.quit();
		}
}

