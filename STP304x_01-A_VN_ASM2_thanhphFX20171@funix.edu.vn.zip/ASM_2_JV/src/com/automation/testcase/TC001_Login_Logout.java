package com.automation.testcase;

import java.io.IOException;
import org.testng.annotations.Test;
import com.automation.base.DriverInstance;
import com.automation.pom.LoginPage;
import com.automation.utils.DataGenerators;
import com.automation.pom.LogoutPage;


public class TC001_Login_Logout extends DriverInstance{

	@Test(dataProvider = "Login", dataProviderClass = DataGenerators.class)
	public void tc_001_login_functionality(String email, String pass) throws IOException, InterruptedException {
				
		LoginPage login = new LoginPage(driver);
		login.clickSignupIcon();

		login.enterEmailAddress(email);
		login.enterPassword(pass);
//		Thread.sleep(2000);
		login.clickLoginButton();
		System.out.println("\nLogin successful");
		
//		Thread.sleep(2000);
		LogoutPage logout = new LogoutPage(driver);
		logout.clickLogoutButton();
		System.out.println("\nLogout successful");
	}
}
