package com.automation.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.automation.utils.CaptureScreenshot;
import com.automation.utils.Utility;
import org.testng.Assert;

public class LoginPage {
	WebDriver driver = null;
	PageActions action;
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		action = new PageActions(driver);
	}

// NHẤN ICON SINGUP/LOGIN ĐỂ CHUYỂN ĐẾN TRANG LOGIN
	public void clickSignupIcon() {
		try {
		action.clickButton(driver.findElement(By.xpath(Utility.fetchLocatorValue("icon_signin_xpath"))));
		}
		catch (Exception e) {
			System.out.println("*************Exception************");
			e.printStackTrace();
			CaptureScreenshot.takeScreenshot(driver, "clickButtonFail");
			Assert.fail();
		}
	}
	
// ĐIỀN EMAIL	
	public void enterEmailAddress(String email) {
	 try {
		action.enterDataIntoText(driver.findElement(By.xpath(Utility.fetchLocatorValue("login_email_xpath"))),email);
		}
	catch (Exception e) {
		System.out.println("*************Exception************");
		e.printStackTrace();
		CaptureScreenshot.takeScreenshot(driver, "EnterDataFail");
		Assert.fail();
		}
	}
	
// ĐIỀN PASSWORD	
	public void enterPassword(String password){
		try {
		action.enterDataIntoText(driver.findElement(By.xpath(Utility.fetchLocatorValue("login_password_xpath"))),password);
		}
	catch (Exception e) {
		System.out.println("*************Exception************");
		e.printStackTrace();
		CaptureScreenshot.takeScreenshot(driver, "EnterDataFail");
		Assert.fail();
		}
	}

		
// NHẤN NÚT SINGUP
	public void clickLoginButton() {
		try {
		action.clickButton(driver.findElement(By.xpath(Utility.fetchLocatorValue("login_button_xpath"))));
		}
		catch (Exception e) {
			System.out.println("*************Exception************");
			e.printStackTrace();
			CaptureScreenshot.takeScreenshot(driver, "clickButtonFail");
			Assert.fail();
		}
	}
		
}
