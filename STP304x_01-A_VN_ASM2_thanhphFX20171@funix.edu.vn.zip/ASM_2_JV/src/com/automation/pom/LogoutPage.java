package com.automation.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.automation.utils.CaptureScreenshot;
import com.automation.utils.Utility;

public class LogoutPage {

	WebDriver driver = null;
	PageActions action;
	public LogoutPage(WebDriver driver) {
		this.driver = driver;
		action = new PageActions(driver);
	}
	
// NHẤN NÚT LOGOUT
	public void clickLogoutButton()  {
		try {
		action.clickButton(driver.findElement(By.xpath(Utility.fetchLocatorValue("icon_signout_xpath"))));
		}
		catch (Exception e) {
			System.out.println("*************Exception************");
			e.printStackTrace();
			CaptureScreenshot.takeScreenshot(driver, "clickButtonFail");
			Assert.fail();
		}
	}
	
}
