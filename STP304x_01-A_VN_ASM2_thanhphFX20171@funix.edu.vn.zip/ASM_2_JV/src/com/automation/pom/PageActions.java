package com.automation.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.automation.utils.CaptureScreenshot;



public class PageActions {
	WebDriver driver = null;
	WebDriverWait wait;
	public PageActions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,20);
	}
//ACTION CLICK BUTTON
	public void clickButton(WebElement element) {
		try {
			wait.until(ExpectedConditions.elementToBeClickable(element));
			element.click();
		} catch (Exception e) {
			System.out.println("*************Exception************");
			e.printStackTrace();
			CaptureScreenshot.takeScreenshot(driver, "clickButtonFail");
			Assert.fail();
		}
	}
//ACTION ĐIỀN THÔNG TIN VÀO Ô TEXT	
	public void enterDataIntoText(WebElement element, String text) {
		try {
			wait.until(ExpectedConditions.visibilityOf(element));
			element.sendKeys(text);
		} catch (Exception e) {
			System.out.println("*************Exception************");
			e.printStackTrace();
			CaptureScreenshot.takeScreenshot(driver, "enterDataFail");
			Assert.fail();		
		}
	}
}
