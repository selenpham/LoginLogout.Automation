package com.automation.utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class DataGenerators {
	
//Đọc và lấy các thông tin từ 1 sheet trong file excel
	@DataProvider(name="Login")
	public static Object[][] testDataGeneratorRegister() throws IOException
	{
		FileInputStream file = new FileInputStream("./Data/assignment2_data_test.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet loginSheet = workbook.getSheet("Login");
		int numberOfData = loginSheet.getPhysicalNumberOfRows();
		Object [][] testData =new Object[numberOfData][2];
// Tạo vòng lặp để đọc các giá trị ở từng  cột trong i dòng
		for(int i = 0; i<numberOfData;i++)
		{
			XSSFRow row = loginSheet.getRow(i);
			XSSFCell email_address = row.getCell(0);
			XSSFCell password = row.getCell(1);
// Lấy data ở 2 cột ở mỗi hàng, gán vào object, mỗi object gồm 2 phần tử email, pass
			testData[i][0] = email_address.getStringCellValue();
			testData[i][1] = password.getStringCellValue();
		}
		return testData;
	}
}
