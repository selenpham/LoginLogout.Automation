package com.automation.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;


public class Utility {
// Đọc file từ Configs.properties
	public static Object fetchPropertyValue(String key) throws IOException {
		FileInputStream file = new FileInputStream("./ConfigurationFile/Configs.properties");
		Properties property = new Properties();
		property.load(file);
		return property.get(key);
	}

	// Đọc file từ Elements.properties
	public static String fetchLocatorValue(String key) throws IOException {
		FileInputStream file = new FileInputStream("./ConfigurationFile/Elements.properties");
		Properties property = new Properties();
		property.load(file);
		return property.get(key).toString();
	}
}

